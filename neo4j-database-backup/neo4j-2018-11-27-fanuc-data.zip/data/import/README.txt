Neo4j Import Data
=======================================

If `dbms.security.load_csv_file_url_root=data/import` is enabled, then files
placed into this directory are accessible using file URLs (`file:///`)
with the `LOAD CSV` clause in Cypher.
